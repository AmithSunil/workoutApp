-- APPLIED 2026-10-07 (pasted into the SQL editor; ledger row `auth_rls`, version
-- 20261007000001). Was supabase/future/20260901000001_auth_rls.sql.pending.
-- The real per-role policy set, written and tested.
--
-- Tested on 2026-08-31 by applying this file inside a transaction, signing in as
-- the trainer and two clients via request.jwt.claims, counting what each could
-- see, and rolling back. `tests/rls.sql` is that test, re-runnable at any time.
-- Results are recorded at the bottom of this file.
--
-- Prerequisites, all already met:
--   1. users.auth_user_id exists and the helper predicates are applied
--      (migration 20260831103659).
--   2. Every person who needs to sign in has an auth.users row linked to their
--      users row (seed/auth_dev_users.sql for the fixtures).
--
--   3. The app signs in with real tokens (src/app/sign-in.tsx, done).
--   4. The onboarding migrations 20260915101634..05 are applied -- the insert
--      policies and routines.author_id below depend on them.
--
-- Held back only for the onboarding checkpoint review (tasks/todo.md, T10).
--
-- Applying it is this file, in one transaction. Nothing else changes: the RPCs
-- are SECURITY INVOKER and will simply start obeying these policies.

-- ---------------------------------------------------------------------------
-- Two more predicates, needed only here
-- ---------------------------------------------------------------------------

create function public.owns_routine(p_routine_id text)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.routines r
                  where r.id = p_routine_id
                    and (r.trainer_id = public.app_user_id() or r.author_id = public.app_user_id()));
$$;

/** A trainer sees their own templates; a client sees the ones assigned to them. */
create function public.can_read_routine(p_routine_id text)
returns boolean language sql stable security definer set search_path = '' as $$
  select public.owns_routine(p_routine_id)
      or exists (select 1 from public.routine_assignments a
                  where a.routine_id = p_routine_id and a.client_id = public.app_user_id());
$$;

-- ---------------------------------------------------------------------------
-- Out with the development posture
-- ---------------------------------------------------------------------------

do $$ declare p record; begin
  for p in select policyname, tablename from pg_policies
            where schemaname = 'public' and policyname like '%\_dev\_%'
  loop execute format('drop policy %I on public.%I', p.policyname, p.tablename); end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Reference data: readable by anyone signed in, maintained by trainers
-- ---------------------------------------------------------------------------

create policy exercises_read  on exercises for select to authenticated using (true);
create policy exercises_write on exercises for all to authenticated
  using (public.app_role() = 'trainer') with check (public.app_role() = 'trainer');
create policy foods_read  on foods for select to authenticated using (true);
create policy foods_write on foods for all to authenticated
  using (public.app_role() = 'trainer') with check (public.app_role() = 'trainer');

-- ---------------------------------------------------------------------------
-- Identity
-- ---------------------------------------------------------------------------

-- Three ways to be visible: you, someone you coach, or the coach you belong to.
create policy users_visible on users for select to authenticated
  using (id = public.app_user_id() or public.is_trainer_of(id) or public.is_my_trainer(id));
-- No self-update policy on users, deliberately. RLS cannot restrict columns, so
-- `using (id = app_user_id())` also permits `update users set role = 'trainer'`
-- -- and app_role() reads that column, so a client could promote themselves to
-- coach in one statement and every is_trainer_of()/app_role() test downstream
-- would start agreeing. Nothing in the app updates users at all (the only
-- writer is link_auth_user, which is DEFINER), so the policy bought nothing.
-- If self-editing of name/avatar is ever wanted, grant the columns rather than
-- the row -- `grant update (name, avatar_url) on users to authenticated`
-- beside a policy -- so role and auth_user_id stay out of reach.

create policy trainer_profiles_visible on trainer_profiles for select to authenticated
  using (id = public.app_user_id() or public.is_my_trainer(id));
-- app_role() as well as the id: without it a client whose id is c-001 could
-- insert trainer_profiles(id = 'c-001') and appear as a coach in every view
-- that joins this table. create_profile is DEFINER and does not pass here.
create policy trainer_profiles_self on trainer_profiles for all to authenticated
  using      (id = public.app_user_id() and public.app_role() = 'trainer')
  with check (id = public.app_user_id() and public.app_role() = 'trainer');

-- A client reads their own profile but does not edit it: macro targets, goals
-- and compliance are the coach's to set.
--
-- This is also the roster gate, and it needed no edit for it: 20260920121309
-- put plan_active() inside owns_client() itself, so a lapsed coach's roster,
-- dashboard counts, client detail and every table below keyed on a client_id
-- all return nothing together. A client's own access is the other branch of
-- that predicate and never consults billing.
create policy client_profiles_visible on client_profiles for select to authenticated
  using (public.owns_client(id));
create policy client_profiles_trainer_writes on client_profiles for all to authenticated
  using (public.is_trainer_of(id) and public.plan_active())
  with check (public.is_trainer_of(id) and public.plan_active());

-- Onboarding (20260915101705). is_trainer_of() looks the row up in its own
-- table, and an INSERT check runs before the new row is visible, so the
-- `for all` policies above can never admit an insert. These key on the column.
create policy users_trainer_insert_client on users for insert to authenticated
  with check (role = 'client' and public.app_role() = 'trainer');
-- Only a client nobody has signed in as yet (revoke_invite).
create policy users_trainer_delete_pending on users for delete to authenticated
  using (auth_user_id is null and public.is_trainer_of(id));
create policy client_profiles_trainer_insert on client_profiles for insert to authenticated
  with check (trainer_id = public.app_user_id() and public.app_role() = 'trainer');
-- The app_role() clause is the second half of the same rule: trainer_id alone
-- would let a *client* hang a roster row off themselves (pointing it at a coach
-- who has no client_profiles row yet), and is_trainer_of() would then answer
-- true for them.
--
-- Self-signup (20260919094856) does not pass through the policy above at all:
-- create_profile is SECURITY DEFINER, because the caller has no users row yet
-- and so has no app_role() for any policy to test. The trainer_id half is what
-- stops a *coach* inserting a client onto someone else's roster.

-- A coached client still gets no update policy: complete_intake (DEFINER) is
-- the only way they write their own profile, so macros stay the coach's.
--
-- An individual has no coach to set them, so they set them. The predicate is
-- what keeps the two apart, not discipline: the moment a coach adopts them
-- (invite_client, S11) trainer_id stops being null and this policy stops
-- matching, mid-session, with no other change anywhere.
create policy client_profiles_self_writes on client_profiles for update to authenticated
  using      (id = public.app_user_id() and trainer_id is null)
  with check (id = public.app_user_id() and trainer_id is null);

-- ---------------------------------------------------------------------------
-- Everything hanging off a client_id: the client, or their trainer
-- ---------------------------------------------------------------------------

do $$
declare t text;
begin
  foreach t in array array['workout_sessions','workout_logs','nutrition_days','food_entries',
                           'body_metrics','progress_photos','habits','check_ins',
                           'ai_food_suggestions','routine_assignments']
  loop
    execute format(
      'create policy %I on public.%I for all to authenticated '
      'using (public.owns_client(client_id)) with check (public.owns_client(client_id))',
      t || '_owner', t);
  end loop;
end $$;

-- Alerts are raised by the system on the trainer's behalf and resolved by them;
-- a client can see their own but must not clear them.
create policy alerts_read on red_flag_alerts for select to authenticated
  using (public.owns_client(client_id));
create policy alerts_trainer_write on red_flag_alerts for all to authenticated
  using (public.is_trainer_of(client_id)) with check (public.is_trainer_of(client_id));

-- ---------------------------------------------------------------------------
-- Child tables: no client_id of their own, so they gate on their parent
-- ---------------------------------------------------------------------------

do $$
declare r record;
begin
  for r in select * from (values
    ('session_exercises',
     'exists (select 1 from public.workout_sessions s where s.id = session_exercises.session_id and public.owns_client(s.client_id))'),
    ('prescribed_sets',
     'exists (select 1 from public.session_exercises x join public.workout_sessions s on s.id = x.session_id where x.id = prescribed_sets.session_exercise_id and public.owns_client(s.client_id))'),
    ('logged_exercises',
     'exists (select 1 from public.workout_logs l where l.id = logged_exercises.workout_log_id and public.owns_client(l.client_id))'),
    ('logged_sets',
     'exists (select 1 from public.logged_exercises x join public.workout_logs l on l.id = x.workout_log_id where x.id = logged_sets.logged_exercise_id and public.owns_client(l.client_id))'),
    ('habit_completions',
     'exists (select 1 from public.habits h where h.id = habit_completions.habit_id and public.owns_client(h.client_id))'),
    ('routine_assignment_days',
     'exists (select 1 from public.routine_assignments a where a.id = routine_assignment_days.assignment_id and public.owns_client(a.client_id))'),
    ('routine_assignment_exercises',
     'exists (select 1 from public.routine_assignment_days d join public.routine_assignments a on a.id = d.assignment_id where d.id = routine_assignment_exercises.assignment_day_id and public.owns_client(a.client_id))')
  ) as v(tbl, pred)
  loop
    execute format('create policy %I on public.%I for all to authenticated using (%s) with check (%s)',
                   r.tbl || '_via_parent', r.tbl, r.pred, r.pred);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Routines: the trainer's library, readable by whoever it is assigned to
-- ---------------------------------------------------------------------------

create policy routines_read on routines for select to authenticated
  using (public.can_read_routine(id));
-- The coach's own templates, or a routine its author wrote for themselves:
-- under their coach's id when they have one (a coach who does not track
-- workouts), and with no coach at all when they are training on their own
-- (20260919094839 made routines.trainer_id nullable). Either way the author
-- must be the caller, so this never widens to someone else's routine.
create policy routines_owner on routines for all to authenticated
  using (trainer_id = public.app_user_id()
         or (author_id = public.app_user_id()
             and (trainer_id is null or public.is_my_trainer(trainer_id))))
  with check (trainer_id = public.app_user_id()
         or (author_id = public.app_user_id()
             and (trainer_id is null or public.is_my_trainer(trainer_id))));

create policy routine_days_read on routine_days for select to authenticated
  using (public.can_read_routine(routine_id));
create policy routine_days_owner on routine_days for all to authenticated
  using (public.owns_routine(routine_id)) with check (public.owns_routine(routine_id));

create policy routine_exercises_read on routine_exercises for select to authenticated
  using (exists (select 1 from routine_days d
                  where d.id = routine_exercises.routine_day_id and public.can_read_routine(d.routine_id)));
create policy routine_exercises_owner on routine_exercises for all to authenticated
  using (exists (select 1 from routine_days d
                  where d.id = routine_exercises.routine_day_id and public.owns_routine(d.routine_id)))
  with check (exists (select 1 from routine_days d
                  where d.id = routine_exercises.routine_day_id and public.owns_routine(d.routine_id)));

-- ---------------------------------------------------------------------------
-- Messaging: both parties, and you can only send as yourself
-- ---------------------------------------------------------------------------

create policy threads_participants on threads for all to authenticated
  using (public.in_thread(id)) with check (public.in_thread(id));
create policy threads_trainer_insert on threads for insert to authenticated
  with check (trainer_id = public.app_user_id());
create policy messages_read on messages for select to authenticated
  using (public.in_thread(thread_id));
create policy messages_send on messages for insert to authenticated
  with check (public.in_thread(thread_id) and sender_id = public.app_user_id());
create policy messages_update on messages for update to authenticated
  using (public.in_thread(thread_id)) with check (public.in_thread(thread_id));

-- ---------------------------------------------------------------------------
-- Billing (20260920121309): read your own, and nothing else
-- ---------------------------------------------------------------------------

-- The price list is public to anyone signed in -- the paywall has to render it.
create policy plans_read on plans for select to authenticated using (true);

-- A subscription is readable by its owner and writable by nobody: every write
-- comes from the razorpay edge functions under the service role, which
-- bypasses RLS. That is deliberate -- a client that could update this table
-- could grant itself a plan. 20260920121309 also revokes the write *grants*,
-- so this is belt as well as braces.
-- 20260920132812 already created this one on the remote; replace it.
drop policy if exists subscriptions_self_read on subscriptions;
create policy subscriptions_self_read on subscriptions for select to authenticated
  using (user_id = public.app_user_id());

-- id_sequences deliberately gets no policy: RLS is on and nothing can reach it.
-- next_id() is SECURITY DEFINER and owned by postgres, which bypasses RLS, so
-- the counters stay reachable exactly one way.

-- ---------------------------------------------------------------------------
-- Measured behaviour (tests/rls.sql, 2026-08-31)
-- ---------------------------------------------------------------------------
--
--                        trainer t-001   client c-001   client c-002   anon
--   client_profiles              8              1              -          0
--   workout_logs               144             44             10          0
--   logged_sets               2290            700              -          0
--   nutrition_days             177             45              -          0
--   body_metrics                 -             72              -          -
--   threads                      8              1              1          0
--   messages                    27              6              -          0
--   users                        9              2              -          -
--   exercises                   32             32              -          0
--
--   c-001 rows visible to c-002: 0.  Other clients' logs visible to c-001: 0.
--
-- Re-run 2026-09-19 after the two edits above (offline Postgres 16, whole
-- migration chain + seed.sql): every number in the table is unchanged, and the
-- self-signup cases read --
--
--   an individual updating their own macros        1 row   (client_profiles_self_writes)
--   a coached client updating their own macros     0 rows  (unchanged; complete_intake only)
--   an individual updating another client's row    0 rows
--   an individual creating their own routine       ok, trainer_id null, author_id theirs
--   a coached client self-planning a routine       ok      (unchanged)
--
-- 2026-09-19, role-escalation edits (users_self_update dropped, app_role()
-- added to trainer_profiles_self and client_profiles_trainer_insert): NOT
-- replayed -- no test was asked for. tests/rls.sql carries the three cases
-- (c1_role_after_self_promote, c1_mints_trainer_profile, c1_fake_roster) and
-- they run with the rest of this file at T10.
--
-- 2026-09-20, billing (20260920121309). Re-run offline against the whole chain
-- + seed.sql + this file. plan_active() went inside owns_client(), so the gate
-- is the predicate ~20 tables already route through, not a clause per policy.
--
--                                   t-001 paid   t-001 lapsed   c-001
--   client_profiles                        8            0          1
--   workout_logs                         144            0         44
--   logged_sets                         2290            0          -
--   body_metrics                         504            0          -
--   nutrition_days                         -            0          -
--   threads                                -            -          1
--
--   Every paid-coach number above is the one recorded in the table further up:
--   a coach with a plan sees exactly what they saw before this existed.
--
--   a lapsed coach updating a client's macros      0 rows
--   a client reading their coach's billing         0 rows (they have none)
--   a client writing subscriptions                 permission denied (grant, not policy)
--   an individual reading their own subscription   1 row, solo/trialing, 14 days
--   an individual editing their own macros         1 row (unchanged by billing)
--   anon                                           0 everywhere (unchanged)
--
-- 2026-09-20, second run: `tests/rls.sql` now runs to completion for the first
-- time since the S4 edits -- 66 cases, every number above reproduced exactly.
-- It had been failing on a line that predates all of this: the seed writes
-- explicit ids without advancing id_sequences, so next_id('c') minted c-001 and
-- invite_client collided on users_pkey. Fixed at the source (seed.sql and
-- seed.mjs now end with a derived counter bump), not here.
--
--   restored_clients reads 9, not 8, and that is correct: the onboarding
--   section above invites two clients and revokes one before the billing cases
--   run. It is the count after that sequence, not a discrepancy.
