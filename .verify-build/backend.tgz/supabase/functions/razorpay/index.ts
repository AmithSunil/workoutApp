/**
 * Razorpay, the parts that need a secret: creating a subscription and
 * cancelling one. Called with the user's JWT; nothing here trusts the body for
 * identity.
 *
 * Checkout itself is Razorpay's own hosted page — the `short_url` a created
 * subscription comes back with. The app opens it with expo-web-browser, which
 * is already a dependency, so there is no native SDK and web and android take
 * exactly the same path. The webhook, not the browser, is what activates the
 * plan; the app just refetches when the browser closes.
 *
 * Secrets (supabase secrets set):
 *   RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET
 */
import { createClient } from 'jsr:@supabase/supabase-js@2';

const RZP = 'https://api.razorpay.com/v1';
const auth = 'Basic ' + btoa(`${Deno.env.get('RAZORPAY_KEY_ID')}:${Deno.env.get('RAZORPAY_KEY_SECRET')}`);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } });

async function razorpay(path: string, init?: RequestInit) {
  const res = await fetch(`${RZP}${path}`, {
    ...init,
    headers: { Authorization: auth, 'Content-Type': 'application/json' },
  });
  const body = await res.json();
  if (!res.ok) throw new Error(body?.error?.description ?? `Razorpay ${res.status}`);
  return body;
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ message: 'Method not allowed' }, 405);

  const token = req.headers.get('Authorization') ?? '';
  // The caller's own client: app_user_id() reads the token, so who they are is
  // never a parameter. Same rule as create_profile.
  const asUser = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_ANON_KEY')!,
    { global: { headers: { Authorization: token } } },
  );
  const admin = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  const { data: userId } = await asUser.rpc('app_user_id');
  if (!userId) return json({ message: 'Sign in first' }, 401);

  let body: { action?: string; planCode?: string };
  try {
    body = await req.json();
  } catch {
    return json({ message: 'Bad request' }, 400);
  }

  try {
    if (body.action === 'cancel') {
      const { data: sub } = await admin
        .from('subscriptions').select('razorpay_subscription_id').eq('user_id', userId).single();
      if (!sub?.razorpay_subscription_id) return json({ message: 'Nothing to cancel' }, 404);
      // cancel_at_cycle_end: they paid for this period and keep it. The row's
      // current_period_end is what lets them in until it passes.
      await razorpay(`/subscriptions/${sub.razorpay_subscription_id}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ cancel_at_cycle_end: 1 }),
      });
      await admin.from('subscriptions').update({ status: 'cancelled' }).eq('user_id', userId);
      return json({ ok: true });
    }

    const { data: plan } = await admin
      .from('plans').select('code, razorpay_plan_id').eq('code', body.planCode ?? '').single();
    if (!plan) return json({ message: 'Unknown plan' }, 404);
    if (!plan.razorpay_plan_id) return json({ message: 'That plan is free' }, 400);

    const created = await razorpay('/subscriptions', {
      method: 'POST',
      body: JSON.stringify({
        plan_id: plan.razorpay_plan_id,
        // ponytail: 120 monthly cycles is Razorpay's way of saying "until
        // cancelled" — it has no open-ended total_count.
        total_count: 120,
        customer_notify: 1,
        notes: { user_id: userId },
      }),
    });

    // The plan_code is written now so the app can show "upgrading to Pro"
    // while the mandate is pending; the webhook is what moves the dates.
    await admin.from('subscriptions').update({
      plan_code: plan.code,
      razorpay_subscription_id: created.id,
      razorpay_customer_id: created.customer_id ?? null,
    }).eq('user_id', userId);

    return json({ shortUrl: created.short_url });
  } catch (e) {
    return json({ message: e instanceof Error ? e.message : 'Payment setup failed' }, 502);
  }
});
