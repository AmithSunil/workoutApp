# Architecture

A single React Native (Expo) codebase serving two products — a client app and a
trainer app — over one shared data layer.

## Layers

```
src/app/          Routing only. Screens compose features; they hold no data logic.
src/api/          Transport + endpoints. The only place that knows how data is fetched.
src/store/        Redux Toolkit store, slices for local state, typed hooks.
src/components/   Presentational + connected components, grouped by feature.
src/theme/        Design tokens. No hex value or magic number lives outside this folder.
src/types/        The domain model shared by both roles.
src/utils/        Pure helpers (dates, formatting).
src/navigation/   Route helpers — every path string in the app is defined here.
src/mock-api/     Generated JSON fixtures (see tools/generate-mock-data.js).
```

The dependency rule is one-directional: `app → components → api/store → types/utils`.
Nothing in `components/` imports from `app/`, and nothing outside `src/api` imports
`mockDb`.

## Role-based routing

```
src/app/_layout.tsx              Redux Provider, session hydration, root Stack
src/app/index.tsx                Role gate (auth handshake in production)
src/app/(client)/_layout.tsx     Guard: bounces non-clients
  (tabs)/_layout.tsx             explore · log · workouts · progress + persistent chat FAB
  chat.tsx, session/[id].tsx
src/app/(trainer)/_layout.tsx    Guard: bounces non-trainers
  (tabs)/_layout.tsx             dashboard (triage) · roster · messages
  client/[id].tsx, thread/[id].tsx
src/app/workout-log/[id].tsx     Shared by both roles
```

Each group layout reads `session.role` from Redux and `<Redirect>`s before any
screen in its subtree renders, so a client can never reach a trainer route by
deep link and vice versa.

## Data layer

Every read and write goes through **RTK Query**, split by feature area with
`injectEndpoints`:

| Module | Owns |
| --- | --- |
| `api/endpoints/nutritionApi` | Days, entries, food search, AI suggestions |
| `api/endpoints/workoutsApi` | Programme, sessions, logs, exercise library |
| `api/endpoints/progressApi` | Body metrics, photos, habits |
| `api/endpoints/messagingApi` | Threads, messages, read receipts |
| `api/endpoints/trainerApi` | Roster, summary, alerts, check-ins, compliance |

`api/mockBaseQuery.ts` is a drop-in replacement for `fetchBaseQuery`: same
argument shape (`{ url, method, params, body }`), simulated latency, real HTTP
status codes. It dispatches to URL-shaped handlers in `api/handlers.ts` which
mutate an in-memory database seeded from `src/mock-api/*.json`.

**Swapping to a real backend is a one-line change** in `api/baseApi.ts`:

```ts
baseQuery: fetchBaseQuery({ baseUrl: process.env.EXPO_PUBLIC_API_URL })
```

Nothing above the transport changes — every `injectEndpoints` call, cache tag and
component stays as it is. `api/handlers.ts`, `api/mockDb.ts` and `src/mock-api/`
are then deleted.

Because writes mutate the in-memory db, they behave like a real server: log a
meal and the trainer's compliance numbers move; finish a session at RPE 9 and a
red-flag alert appears on the triage dashboard.

## What lives in Redux vs RTK Query

RTK Query owns anything the server owns. Plain slices own only what it doesn't:

- `sessionSlice` — who is signed in, which client is being viewed, the active
  date. Persisted to AsyncStorage (`store/persistence.ts`).
- `workoutDraftSlice` — the in-progress workout. Sets are edited many times a
  second mid-session; only the finished log is POSTed.
- `uiSlice` — roster search and filter, selected nested tab, pending meal slot.

## Design system

`src/theme/tokens.ts` defines colour, spacing, radius, elevation, motion and the
type scale. `src/components/ui/` wraps them into primitives — `Text` is the only
text component in the app, so the type scale stays auditable in one file.

Charts are hand-built on `react-native-svg` (`components/charts/`) rather than a
chart library, which keeps the visual language consistent with the rest of the
system and avoids a dependency that would need re-styling anyway.

## Verification

`npm run verify` (`tools/verify.js`) runs three stages, cross-platform:

1. **Typecheck** — TypeScript in strict mode across the whole tree.
2. **Native bundle** — `expo export --platform android`. This stage is not
   optional: Metro's *web* target silently shims Node builtins that native does
   not, so a web-only check will pass on an import that crashes on device. That
   is exactly how `react-native-svg`'s undeclared `buffer` import slipped
   through the first time.
3. **Browser walkthrough** — bundles for web, serves it (`tools/serve.js`) and
   drives both role shells in headless Chromium (`tools/screenshot.js`), failing
   on any console error or uncaught exception and writing screenshots to
   `shots/`. Skipped gracefully when no Chromium binary is found; point
   `CHROME_PATH` at one to enable it.

### Why `buffer` is a direct dependency

`react-native-svg@15.13.0` does `import { Buffer } from 'buffer'` in
`src/utils/fetchData.ts` without declaring `buffer` in its own dependencies.
Metro resolves it on web and fails on native. `buffer` is therefore pinned in
`package.json` on purpose — do not remove it as an unused dependency. It can go
once react-native-svg ships a version that declares or drops the import.

## Known constraints of the demo build

- Avatars and progress photos reference remote placeholder services
  (`i.pravatar.cc`, `picsum.photos`). Offline, avatars fall back to monograms
  and photo tiles to gradients. Swap `avatarUrl` / `uri` in the mock data for
  real assets.
- `TODAY` in `src/utils/date.ts` is pinned to the dataset's anchor date so the
  demo is reproducible. Replace it with `new Date()` when a live backend lands.
- The AI food parser matches typed text against fixtures in
  `mock-api/aiSuggestions.json`; the confirmation-card flow around it is the
  real, production-shaped interaction.
