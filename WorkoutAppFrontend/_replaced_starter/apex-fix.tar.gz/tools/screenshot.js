/* eslint-disable */
/**
 * Smoke test + visual capture.
 *
 * Serves the exported web build (see tools/serve.js) and drives both role shells
 * the way a user would, failing on any console error or uncaught exception.
 * Screenshots land in ./shots.
 *
 *   node tools/serve.js /tmp/webbuild 8099 &
 *   node tools/screenshot.js
 */
const { chromium } = require('playwright-core');
const fs = require('fs');
const path = require('path');

const BASE = 'http://127.0.0.1:8099';
const OUT = path.join(__dirname, '..', 'shots');
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

const errors = [];
const IGNORE = [
  /Download the React DevTools/i,
  /pravatar|picsum/i, // remote demo avatars/photos are unreachable in the sandbox
  /Failed to load resource/i,
  /net::ERR/i,
];

/**
 * Resolve a Chromium binary. CHROME_PATH wins; otherwise fall back to the
 * locations Playwright and a normal Chrome install use, so this runs on a dev
 * machine as well as in CI.
 */
const findChrome = () => {
  if (process.env.CHROME_PATH) return process.env.CHROME_PATH;
  const candidates = [
    '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    '/usr/bin/google-chrome',
    '/usr/bin/chromium',
  ];
  for (const c of candidates) {
    try {
      if (fs.existsSync(c)) return c;
    } catch {}
  }
  const root = process.env.PLAYWRIGHT_BROWSERS_PATH;
  if (root && fs.existsSync(root)) {
    for (const dir of fs.readdirSync(root)) {
      if (!dir.startsWith('chromium-')) continue;
      const bin = path.join(root, dir, 'chrome-linux', 'chrome');
      if (fs.existsSync(bin)) return bin;
    }
  }
  return null;
};

(async () => {
  const executablePath = findChrome();
  if (!executablePath) {
    console.log('\nNo Chromium binary found — set CHROME_PATH to run the walkthrough. Skipping.');
    process.exit(0);
  }

  const browser = await chromium.launch({
    executablePath,
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });

  /** Each role runs in its own context so persisted sessions never leak. */
  let page;
  const freshSession = async (startPath = '/') => {
    if (page) await page.context().close();
    const context = await browser.newContext({
      viewport: { width: 402, height: 874 },
      deviceScaleFactor: 2,
    });
    page = await context.newPage();
    page.on('console', (msg) => {
      if (msg.type() !== 'error') return;
      const text = msg.text();
      if (IGNORE.some((r) => r.test(text))) return;
      errors.push(`[console] ${text}`);
    });
    page.on('pageerror', (err) => errors.push(`[pageerror] ${err.message}`));
    await page.goto(BASE + startPath, { waitUntil: 'networkidle' });
    await page.waitForTimeout(2200);
  };

  let n = 0;
  const shot = async (name) => {
    await page.waitForTimeout(1500);
    n += 1;
    await page.screenshot({ path: path.join(OUT, `${String(n).padStart(2, '0')}-${name}.png`) });
    console.log('  ✓', name, '·', page.url().replace(BASE, '') || '/');
  };

  /** Scoped to the visible screen — inactive tab screens stay mounted on web. */
  const click = async (locator, label) => {
    await locator.locator('visible=true').last().click({ timeout: 15000 });
    await page.waitForTimeout(900);
    console.log('  → clicked', label);
  };

  const go = async (route) => {
    await page.goto(BASE + route, { waitUntil: 'networkidle' });
    await page.waitForTimeout(1800);
  };

  console.log('\nROLE GATE');
  await freshSession();
  await shot('role-select');

  console.log('\nCLIENT');
  await click(page.getByText('Aditya Rao'), 'sign in as Aditya Rao');
  await shot('client-explore');

  await click(page.getByLabel('Log', { exact: true }), 'Log tab');
  await shot('client-nutrition-log');

  await click(page.getByLabel('Add to Breakfast'), 'add to breakfast');
  await shot('client-food-picker');
  await click(page.getByText('✨ Describe it'), 'AI tab');
  await click(page.getByText('protein shake and almonds'), 'AI example');
  await click(page.getByText('Parse with AI'), 'parse');
  await shot('client-ai-confirmation');

  await click(page.getByLabel('Workouts', { exact: true }), 'Workouts tab');
  await shot('client-workouts');

  await click(page.getByText('Start session'), 'start session');
  await shot('client-active-session');
  await page.mouse.wheel(0, 2600);
  await shot('client-rpe-slider');

  await click(page.getByLabel('Go back'), 'back');
  await click(page.getByLabel('Progress', { exact: true }), 'Progress tab');
  await shot('client-progress');

  await click(page.getByLabel('Message coach'), 'chat FAB');
  await shot('client-chat');

  console.log('\nTRAINER');
  await freshSession();
  await click(page.getByText('Maya Fernandes'), 'sign in as trainer');
  await shot('trainer-triage');
  await page.mouse.wheel(0, 1000);
  await shot('trainer-alerts');
  await page.mouse.wheel(0, 1400);
  await shot('trainer-checkins');

  await click(page.getByLabel('Clients', { exact: true }), 'Clients tab');
  await shot('trainer-roster');

  await go('/client/c-004');
  await shot('trainer-client-metrics');
  await click(page.getByText('Nutrition', { exact: true }), 'nutrition tab');
  await shot('trainer-client-nutrition');
  await click(page.getByText('Workouts', { exact: true }), 'workouts tab');
  await shot('trainer-client-workouts');
  await click(page.getByText('Plan', { exact: true }), 'plan tab');
  await shot('trainer-client-plan');

  await go('/messages');
  await shot('trainer-messages');

  await go('/thread/th-c-005');
  await shot('trainer-thread');
  await click(page.getByLabel('Attach a log'), 'attach a log');
  await shot('trainer-attach-picker');

  await go('/workout-log/wl-00001');
  await shot('workout-log-detail');

  await browser.close();

  if (errors.length) {
    console.error('\n--- RUNTIME ERRORS ---');
    for (const e of [...new Set(errors)]) console.error(e);
    process.exit(1);
  }
  console.log('\n✓ No runtime errors across', n, 'captures.');
})().catch((err) => {
  console.error('\nFAILED:', err.message.split('\n')[0]);
  process.exit(1);
});
