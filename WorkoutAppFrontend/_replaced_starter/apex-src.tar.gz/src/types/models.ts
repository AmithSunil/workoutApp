/**
 * Domain model shared by both sides of the product.
 * These mirror the shape the BaaS layer is expected to return, so swapping the
 * mock transport for a live one requires no changes above the API layer.
 */

export type UserRole = 'client' | 'trainer';

export type ISODate = string; // YYYY-MM-DD
export type ISODateTime = string; // full ISO 8601

export interface User {
  id: string;
  role: UserRole;
  name: string;
  avatarUrl: string;
  email: string;
}

export interface TrainerProfile extends User {
  role: 'trainer';
  headline: string;
  clientIds: string[];
}

export type ComplianceStatus = 'green' | 'yellow' | 'red';

export interface MacroTargets {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface ClientProfile extends User {
  role: 'client';
  trainerId: string;
  goal: 'cut' | 'recomp' | 'bulk' | 'performance';
  heightCm: number;
  startWeightKg: number;
  targetWeightKg: number;
  targets: MacroTargets;
  joinedAt: ISODate;
  /** Rolled up by the backend; drives the roster traffic lights. */
  compliance: {
    status: ComplianceStatus;
    /** 0–100 over the trailing 7 days. */
    score: number;
    lastLoggedAt: ISODateTime | null;
    streakDays: number;
  };
}

/* -------------------------------------------------------------------------- */
/* Nutrition                                                                   */
/* -------------------------------------------------------------------------- */

export type MealSlot = 'breakfast' | 'lunch' | 'dinner' | 'snack';

export interface FoodItem {
  id: string;
  name: string;
  brand?: string;
  servingLabel: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  emoji: string;
  /** Surfaced in the quick-add carousel when true. */
  frequent?: boolean;
}

export interface FoodEntry {
  id: string;
  clientId: string;
  date: ISODate;
  slot: MealSlot;
  foodId: string;
  name: string;
  servings: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  /** Set when the entry originated from the AI parser rather than search. */
  source: 'search' | 'quick-add' | 'ai';
  loggedAt: ISODateTime;
}

export interface NutritionDay {
  date: ISODate;
  clientId: string;
  targets: MacroTargets;
  consumed: MacroTargets;
  entries: FoodEntry[];
}

/** A parsed, not-yet-committed suggestion from the AI food parser. */
export interface AiFoodSuggestion {
  id: string;
  transcript: string;
  confidence: number;
  items: Array<{
    name: string;
    servings: number;
    servingLabel: string;
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    emoji: string;
  }>;
}

/* -------------------------------------------------------------------------- */
/* Training                                                                    */
/* -------------------------------------------------------------------------- */

export type MuscleGroup =
  | 'chest'
  | 'back'
  | 'legs'
  | 'shoulders'
  | 'arms'
  | 'core'
  | 'full body'
  | 'conditioning';

export interface Exercise {
  id: string;
  name: string;
  muscleGroup: MuscleGroup;
  equipment: string;
}

export interface PrescribedSet {
  reps: number;
  targetWeightKg: number | null;
}

export interface ProgrammedExercise {
  id: string;
  exerciseId: string;
  name: string;
  muscleGroup: MuscleGroup;
  notes?: string;
  sets: PrescribedSet[];
}

export interface WorkoutSession {
  id: string;
  clientId: string;
  title: string;
  /** Day the trainer scheduled it for. */
  scheduledFor: ISODate;
  estimatedMinutes: number;
  focus: MuscleGroup;
  exercises: ProgrammedExercise[];
  status: 'scheduled' | 'in-progress' | 'completed' | 'missed';
}

export interface LoggedSet {
  id: string;
  reps: number;
  weightKg: number;
  completed: boolean;
}

export interface LoggedExercise {
  id: string;
  exerciseId: string;
  name: string;
  muscleGroup: MuscleGroup;
  sets: LoggedSet[];
}

export interface WorkoutLog {
  id: string;
  clientId: string;
  sessionId: string;
  title: string;
  date: ISODate;
  durationMinutes: number;
  /** Rate of Perceived Exertion, 1–10. */
  rpe: number;
  totalVolumeKg: number;
  notes?: string;
  exercises: LoggedExercise[];
  completedAt: ISODateTime;
}

/* -------------------------------------------------------------------------- */
/* Progress                                                                    */
/* -------------------------------------------------------------------------- */

export interface BodyMetric {
  id: string;
  clientId: string;
  date: ISODate;
  weightKg: number;
  bodyFatPct?: number;
  waistCm?: number;
}

export interface ProgressPhoto {
  id: string;
  clientId: string;
  date: ISODate;
  pose: 'front' | 'side' | 'back';
  uri: string;
  weightKg: number;
}

export interface Habit {
  id: string;
  clientId: string;
  title: string;
  icon: string;
  cadence: 'daily';
  /** Dates on which the habit was ticked off. */
  completedDates: ISODate[];
  createdBy: 'trainer' | 'client';
}

/* -------------------------------------------------------------------------- */
/* Communication                                                               */
/* -------------------------------------------------------------------------- */

export type MessageAttachment =
  | { kind: 'workout'; logId: string }
  | { kind: 'nutrition'; date: ISODate }
  | { kind: 'photo'; uri: string };

export interface Message {
  id: string;
  threadId: string;
  senderId: string;
  body: string;
  sentAt: ISODateTime;
  readAt: ISODateTime | null;
  attachment?: MessageAttachment;
}

export interface Thread {
  id: string;
  clientId: string;
  trainerId: string;
  lastMessagePreview: string;
  lastMessageAt: ISODateTime;
  unreadForTrainer: number;
  unreadForClient: number;
}

/* -------------------------------------------------------------------------- */
/* Trainer triage                                                              */
/* -------------------------------------------------------------------------- */

export type AlertKind =
  | 'missed-logs'
  | 'high-rpe'
  | 'weight-stall'
  | 'calorie-deficit-miss'
  | 'check-in-due';

export type AlertSeverity = 'critical' | 'warning' | 'info';

export interface RedFlagAlert {
  id: string;
  clientId: string;
  kind: AlertKind;
  severity: AlertSeverity;
  title: string;
  detail: string;
  raisedAt: ISODateTime;
  resolved: boolean;
}

export interface CheckIn {
  id: string;
  clientId: string;
  weekOf: ISODate;
  submittedAt: ISODateTime;
  status: 'pending' | 'reviewed';
  weightChangeKg: number;
  avgCalories: number;
  targetCalories: number;
  sessionsCompleted: number;
  sessionsPlanned: number;
  avgRpe: number;
  clientNote: string;
}

/** Denormalised numbers the triage dashboard header renders. */
export interface TrainerSummary {
  activeClients: number;
  pendingCheckIns: number;
  unreadMessages: number;
  criticalAlerts: number;
  weeklyComplianceAvg: number;
}
