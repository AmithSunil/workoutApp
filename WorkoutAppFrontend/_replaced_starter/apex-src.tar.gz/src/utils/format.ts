export const clamp = (value: number, min: number, max: number): number =>
  Math.min(max, Math.max(min, value));

/** Safe ratio in the 0–1 range; returns 0 when the denominator is falsy. */
export const ratio = (value: number, total: number): number =>
  total > 0 ? clamp(value / total, 0, 1) : 0;

export const pct = (value: number, total: number): number => Math.round(ratio(value, total) * 100);

export const kg = (value: number, digits = 1): string => `${value.toFixed(digits)} kg`;

export const signed = (value: number, digits = 1): string =>
  `${value > 0 ? '+' : value < 0 ? '−' : ''}${Math.abs(value).toFixed(digits)}`;

export const grams = (value: number): string => `${Math.round(value)}g`;

export const kcal = (value: number): string => `${Math.round(value).toLocaleString('en-US')}`;

export const initials = (name: string): string =>
  name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('');

export const firstName = (name: string): string => name.split(' ')[0] ?? name;

export const volume = (value: number): string =>
  value >= 1000 ? `${(value / 1000).toFixed(1)}t` : `${Math.round(value)} kg`;

export const plural = (count: number, word: string, pluralForm?: string): string =>
  `${count} ${count === 1 ? word : (pluralForm ?? `${word}s`)}`;
