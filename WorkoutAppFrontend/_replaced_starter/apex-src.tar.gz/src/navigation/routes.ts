import type { Href } from 'expo-router';

/**
 * Every navigation target in the app, in one place.
 *
 * Screens never hand-write path strings — they call these helpers. Renaming a
 * route file becomes a single-line change here instead of a repo-wide grep, and
 * typed-routes generation stays contained to this module.
 */
const href = (path: string): Href => path as unknown as Href;

export const routes = {
  roleSelect: () => href('/'),

  client: {
    explore: () => href('/(client)/(tabs)/explore'),
    log: () => href('/(client)/(tabs)/log'),
    workouts: () => href('/(client)/(tabs)/workouts'),
    progress: () => href('/(client)/(tabs)/progress'),
    chat: () => href('/(client)/chat'),
    session: (sessionId: string) => href(`/(client)/session/${sessionId}`),
  },

  trainer: {
    dashboard: () => href('/(trainer)/(tabs)/dashboard'),
    roster: () => href('/(trainer)/(tabs)/roster'),
    messages: () => href('/(trainer)/(tabs)/messages'),
    clientDetail: (clientId: string) => href(`/(trainer)/client/${clientId}`),
    thread: (threadId: string) => href(`/(trainer)/thread/${threadId}`),
  },

  workoutLog: (logId: string) => href(`/workout-log/${logId}`),
} as const;
